# my_functions
This is a set of functions I use when I do data processing in python
